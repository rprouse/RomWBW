@echo off
setlocal

if exist *.exe del *.exe
if exist *.obj del *.obj
if exist *.err del *.err
if exist *.o del *.o
if exist *.bin del *.bin
if exist zxcc del zxcc
if exist zxccdbg del zxccdbg
if exist zxcc_ft del zxcc_ft
if exist zxccdbg_ft del zxccdbg_ft
if exist config.h del config.h
